<hr>
<p class="text-center mb-0">&copy; Copyright all rights reserved to <?= $company->name; ?></p>
</div>

</body>
</html>
