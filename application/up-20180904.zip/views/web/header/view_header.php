<!DOCTYPE html>
<html>
<head>
    <!-- Basic -->
    <meta charset="utf-8">
    <title><?= "{$company->name} :: {$page_title }"; ?></title>
    <meta name="keywords" content=""/>
    <meta name="description" content="<?= "{$company->name} - {$company->tagline}" ?>">
    <meta name="author" content="Big M Resources Limited">
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo base_url( 'images/favicon.png' ); ?>">
    <!-- Web Fonts  -->
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <!--    <link href="https://fonts.googleapis.com/css?family=Barlow:100,100i,400,400i,500,500i,700,700i" rel="stylesheet">-->
    <!-- Lib CSS -->
    <link rel="stylesheet" href="<?php echo base_url( 'css_user/lib/bootstrap.min.css' ); ?>">
    <!--    <link rel="stylesheet" href="--><?php //echo base_url('css_user/lib/animate.min.css');?><!--">-->
    <link rel="stylesheet" href="<?php echo base_url( 'css_user/lib/font-awesome.min.css' ); ?>">
    <link rel="stylesheet" href="<?php echo base_url( 'css_user/lib/univershicon.css' ); ?>">
    <link rel="stylesheet" href="<?php echo base_url( 'css_user/lib/owl.carousel.css' ); ?>">
    <!--    <link rel="stylesheet" href="--><?php //echo base_url('css_user/lib/prettyPhoto.css');?><!--">-->
    <link rel="stylesheet" href="<?php echo base_url( "css_user/lib/menu.css?v=" . config_item( 'app_version' ) ); ?>">
    <!--    <link rel="stylesheet" href="--><?php //echo base_url('css_user/lib/timeline.css');?><!--">-->

    <!-- Theme CSS -->
    <link rel="stylesheet" href="<?php echo base_url( "css_user/theme.css?v=" . config_item( 'app_version' ) ); ?>">
    <link rel="stylesheet" href="<?php echo base_url( "css_user/theme-responsive.css?v=" . config_item( 'app_version' ) ); ?>">

    <!--[if IE]>
    <link rel="stylesheet" href="<?php echo base_url('css/ie.css');?>">
    <![endif]-->

    <!-- Skins CSS -->
    <link rel="stylesheet" href="<?php echo base_url( 'css_user/skins/default.css' ); ?>">

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="<?php echo base_url( "css_user/custom.css?v=" . config_item( 'app_version' ) ); ?>">
    <!-- <script src="https://code.jquery.com/jquery-1.10.2.js"></script> -->

    <script type="text/javascript">
        const BASE_URL = '<?= site_url(); ?>';
    </script>


</head>
<body>
