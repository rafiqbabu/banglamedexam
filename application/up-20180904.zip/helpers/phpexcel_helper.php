<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/** PHPExcel */
require_once APPPATH.'helpers/phpexcel/PHPExcel.php';
require_once APPPATH.'helpers/phpexcel/PHPExcel/IOFactory.php';