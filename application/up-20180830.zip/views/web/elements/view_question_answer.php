<?php echo form_hidden( 'id', $question->id ); ?>
<?php echo form_hidden( 'type', $question->type ); ?>
<?php if ( $this->session->ques_no == $this->session->ques_count ): ?>
	<div class="text-warning">Last Question</div>
<?php endif; ?>
<div class="row">
	<div class="col-md-10">
		<p><strong>Q: <?= get_name_by_auto_id( 'oe_qsn_bnk_master', $question->id, 'question_name' ) ?></strong></p>
	</div>
	<div class="col-md-2">
		<?php
		$total_ques = count( $this->session->ques_count );
		$current_ques = array_search( $question->id, $this->session->ques_count ) + 1;
		?>
		<span class="label label-info"><?= $current_ques . " of " . $total_ques; ?></span>
	</div>
</div>

<p><strong>Answer:</strong></p>
<?php if ( $question->type === '1' ) : ?>
	<ul class="q-ans">
		<?php foreach ( $answers as $answer ) :
			if ( $answer->ans ):
				?>
				<li><label><input type="radio" name="ans" value="<?= $answer->index_seqn; ?>"><?= $answer->ans; ?></label></li>
			<?php
			endif;
		endforeach; ?>
	</ul>
<?php elseif ( $question->type === '2' ) : if ( count( $answers ) ) : ?>
	<ul class="q-ans">
		<?php foreach ( $answers as $answer ) :
			if ( $answer ):
				?>
				<li>
					<div class="col-md-8"><?= "<span>{$answer->index_seqn}.</span> <span> {$answer->ans}</span>" ?></div>
					<div class="col-md-4">
						<label><input type="radio" name="ans[<?= $answer->index_seqn; ?>]" value="T"> True</label>
						<label><input type="radio" name="ans[<?= $answer->index_seqn; ?>]" value="F"> False</label>
					</div>
				</li>
			<?php endif;
		endforeach; ?>
	</ul>
<?php endif; endif; ?>
