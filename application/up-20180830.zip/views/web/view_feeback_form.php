<?php $this->load->view( 'web/header/view_header' ); ?>
<!-- Header Begins -->
<?php $this->load->view( 'web/header/header_top' ); ?>
<!-- Page Main -->
<div role="main" class="main">
	<!-- Section -->
	<section class="bg-grey typo-dark">
		<div class="container">
			<div class="row">
				<!-- Column -->
				<div class="col-sm-8 col-md-offset-2">
					<div class="contact-info">
						<div class="info-icon bg-dark">
							<i class="uni-fountain-pen"></i>
						</div>
						<form method="post" action="<?= current_url(); ?>">
							<!-- Field 1 -->
							<div class="input-text form-group">
								<input type="text" name="name" class="input-name form-control" placeholder="Full Name">
							</div>
							<!-- Field 2 -->
							<div class="input-email form-group">
								<input type="email" name="email" class="input-email form-control" placeholder="Email">
							</div>
							<!-- Field 4 -->
							<div class="textarea-message form-group">
								<textarea name="message" class="textarea-message form-control" placeholder="Your Opinion" rows="5"></textarea>
							</div>
							<!-- Button -->
							<button class="btn btn-lg bg-green" type="submit" onclick="submit_form(this, event)">Send Now</button>
						</form>
					</div>
				</div><!-- Column -->
			
			</div><!-- Row -->
		</div><!-- Container -->
	</section><!-- Section -->
</div><!-- Page Main -->

<!-- Footer -->
<?php $this->load->view( 'web/footer/footer' ); ?>
<!-- Footer -->
<script type="text/javascript">
	window.onload = MapLoadScript;
</script>
