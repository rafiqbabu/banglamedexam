<?php $this->load->view( 'web/header/view_header' ); ?>
<!-- Header Begins -->
<?php $this->load->view( 'web/header/header_top' ); ?>
<link href="https://fonts.googleapis.com/css?family=Atomic+Age" rel="stylesheet">
<!-- Page Main -->
<div role="main" class="main">
    <div class="page-default bg-grey team-single">
        <!-- Container -->
        <div class="container">
            <!-- Page Content -->
            <div class="row exam-page">
                <div class="col-md-12">
                    <div class="widget">
                        <?= form_open( "exam-answer-save/{$exam->id}" ); ?>
                        <?php echo $msg; ?>
                        <div class="row">
                            <div class="col-sm-9">
                                <h5 class="widget-title"><?= $page_title; ?> <span></span></h5>
                            </div>

                            <div class="col-sm-3 pull-right">
                                <h5 class="e-head-right">
                                    Remaining: <span class="timer"><?= $exam->duration; ?>:00</span>
                                    <?= form_hidden('timer', $exam->duration); ?>
                                </h5>
                            </div>
                        </div>

                        <div class="question-answer">
                            <?= $question_answer; ?>
                        </div>
                        <div class="clearfix"></div>
                        <hr>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-3">
                                <button type="submit" class="btn btn-lg bg-yellow" onclick="next_question(this, event)" name="skip">Skip <i class="fa fa-clock-o"></i> </button>
                                <button type="submit" class="btn btn-lg bg-green pull-right" onclick="next_question(this, event)" name="next">Next <i class="fa fa-angle-double-right"></i></button>
                            </div>
                            <div class="clearfix"></div>
                        </div>

                        <?= form_close(); ?>
                    </div>
                </div>
            </div>
        </div><!-- Container -->
    </div><!-- Page Default -->
</div><!-- Page Main -->
<!-- Footer -->
<?php $this->load->view( 'web/footer/footer' ); ?>
<!-- Footer -->
<script>
    var time = <?= $exam->duration; ?>;
    $('.timer').jTimer({time: time});

    // $(document).ready(function () {
    //     $(this).on('keydown', function (e) {
    //         if ((e.which || e.keyCode) == 116 || (e.which || e.keyCode) == 82) {
    //             confirm('Are you sure? You\'ll lost access to this exam.');
    //             e.preventDefault();
    //         }
    //     });
    // });
</script>
